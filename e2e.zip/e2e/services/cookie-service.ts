import { dirname } from "path";
import { Actions } from "./playwright/actions";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";

/**
 * Get browser cookies and save them to file with user-email for future use
 * @param action Action
 * @param userEmail User email
 */
export const saveCookies = async (action: Actions, userEmail: string) => {
    const cookies = await action.getCookies();
    if(cookies?.length === 0) {
        return;
    }
    const filePath = `browser-cookies/${userEmail}.json`;
    const dir = dirname(filePath);
    //write reusable data to file for future use
    mkdirSync(dir, { recursive: true });
    writeFileSync(filePath, JSON.stringify(cookies, null, 2)); 
};

/**
 * Read the cookies form file for the user and set them in the browser
 * @param action Action
 * @param userEmail email of user
 * @returns if cookie is present and set to browser or not
 */
export const loadSavedCookies = async (action: Actions, userEmail: string) => {
    const filePath = `browser-cookies/${userEmail}.json`;
    if(!existsSync(filePath)) {
        return false;
    }
    const data = readFileSync(filePath);
    if(!data) {
        return false;
    }
    const cookies = JSON.parse(data.toString());
    if(!cookies?.length || cookies.length === 0) {
        return false;
    }
    await action.setCookies(cookies);
    return true;
};