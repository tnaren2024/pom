export enum LogMarker {
    START = "[[START]]",
    END = "[[END]]",
    ERROR = "[[ERROR]]",
    INFO = "[[INFO]]",
    NONE = "" //no marker
}

/**
 * Logs the start of an action to the console with a [[START]] marker
 * @param message Log message to display
 * @param logLabel Optional label to display in the log
 */

export const startLog = (message: string, logLabel = "") => {
    consoleLog(LogMarker.START, message, logLabel);
};

/**
 * Logs the end of an action to the console with a [[END]] marker
 * @param message Log message to display
 * @param logLabel Optional label to display in the log
 */

export const endLog = (message: string, logLabel = "") => {
    consoleLog(LogMarker.END, message, logLabel);
};

/**
 * Logs error messages to the console with a [[ERROR]] marker
 * @param message
 * @param logLabel
 */
export const errorLog = (message: string, logLabel = "") => {
    consoleLog(LogMarker.ERROR, message, logLabel);
};

/**
 * Logs messages to the console with a custom marker
 * @param logMarker Marker to display in the log
 * @param message Log message to display
 * @param logLabel Optional label to display in the log
 */
export const consoleLog = (logMarker: LogMarker, message: string, logLabel = "") => {
    logLabel = logLabel ? `[${logLabel}] :: ` : "";
    console.log(`${logLabel}${message} ${logMarker}`);
};

/**
 * Logs messages to the console with a custom marker
 * @param logMarker Marker to display in the log
 * @param message Log message to display
 * @param logLabel Optional label to display in the log
 */
export const consoleError = (logMarker: LogMarker, message: string, logLabel = "") => {
    logLabel = logLabel ? `[${logLabel}] :: ` : "";
    console.error(`${logLabel}${message} ${logMarker}`);
};

export const startStep = (message: string, logLabel = "") => {
    logLabel = logLabel ? `[${logLabel}] :: ` : "";
    const logger = new StepLogger(`${logLabel}${message}`);
    logger.start();
    return logger;
};

export const withStepLogs = async (message: string, logLabel = "", callback: () => Promise<any>) => {
    logLabel = logLabel ? `[${logLabel}] :: ` : "";
    const logger = new StepLogger(`${logLabel}${message}`);
    logger.start();
    const ret = await callback();
    logger.end();
    return ret;
};

export class StepLogger {
    private log: string;
    private startTime;

    constructor(log: string) {
        this.log = log;
    }

    public start() {
        console.log(`${this.log} ${LogMarker.START}`);
        this.startTime = Date.now();
    }

    public end() {
        const endTime = Date.now();
        const duration = endTime - this.startTime;
        const durationText = duration > 60000 ? `${duration / 60000}min` : duration > 1000 ? `${duration / 1000}s` : `${duration}ms`;
        console.log(`${this.log} ${LogMarker.END} - ${durationText}`);
    }
}
