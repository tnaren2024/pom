// import { clone } from "lodash";
import { Actions } from "../services/playwright/actions";

export class BasePage {
    protected actions: Actions;

    constructor(actions: Actions, pageLabel: string) {
        this.actions = deepClone (actions);
        this.actions.logLabel = pageLabel;
    }
}

function deepClone<T>(obj: T, seen = new Map()): T {
    // Handle null or non-object types
    if (obj === null || typeof obj !== "object") {
        return obj;
    }

    // Handle circular references
    if (seen.has(obj)) {
        return seen.get(obj);
    }

    // Create the clone (array or object)
    const cloned: any = Array.isArray(obj) ? [] : {};

    // Store the reference to handle circular references
    seen.set(obj, cloned);

    // Recursively clone each property
    for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
            cloned[key] = deepClone((obj as any)[key], seen);
        }
    }

    return cloned;
}
