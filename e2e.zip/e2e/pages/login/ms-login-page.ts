import { startStep } from "../../services/log-handler";
import { Actions } from "../../services/playwright/actions";
import { IElement, LocatorType } from "../../types/element";
import { BasePage } from "../base-page";

export class MicrosoftLoginPage extends BasePage{

    constructor(actions: Actions) {
        super(actions, "MicrosoftLoginPage");
    }

    public elements = {
        emailInput: ():IElement => {
            return {
                label: "emailInput",
                elementLocator: { locator: "//input[@type='email']", locatorType: LocatorType.XPATH },
                backupLocators: [{ locator: "//input[@name='loginfmt']", locatorType: LocatorType.XPATH }]
            };
        },
        passwordInput: ():IElement => {
            return {
                label: "password",
                elementLocator: { locator: "//input[@type='password'][@placeholder]", locatorType: LocatorType.XPATH },
                backupLocators: [{ locator: "//input[@name='passwd'][@placeholder]", locatorType: LocatorType.XPATH }]
            };
        },
        submit: ():IElement => {
            return {
                label: "submit",
                elementLocator: { locator: "//input[@type='submit']", locatorType: LocatorType.XPATH },
                backupLocators: [{ locator: "//input[@data-report-event='Signin_Submit']", locatorType: LocatorType.XPATH }]
            };
        },
        useWebApp: ():IElement => {
            return { label: "useWebApp", elementLocator: { locator: ".use-app-lnk", locatorType: LocatorType.CSS }, backupLocators: [] };
        },
        logBackIn: ():IElement => {
            return {
                label: "logBackIn",
                elementLocator: { locator: "//button[normalize-space()='Log back in']", locatorType: LocatorType.XPATH },
                backupLocators: []
            };
        },
        useAnotherAccount: ():IElement => {
            return {
                label: "logBackIn",
                elementLocator: { locator: "//div[normalize-space()='Use another account']", locatorType: LocatorType.XPATH },
                backupLocators: [{ locator: ".otherTile", locatorType: LocatorType.CSS }]
            };
        },
        staySignedIn: ():IElement => {
            return {
                label: "staySignedIn",
                elementLocator: { locator: "//div[text()='Stay signed in?']", locatorType: LocatorType.XPATH },
                backupLocators: [{ locator: "//div[@class='row text-title']", locatorType: LocatorType.XPATH }]
            };
        },
        loginEmailCard: (user:IUser):IElement => {
            return {
                label: "loginEmailCard",
                elementLocator: { locator: "//div[.='" + user.email + "']", locatorType: LocatorType.XPATH },
                backupLocators: []
            };
        },
        progressBar: (user:IUser):IElement => {
            return {
                label: "progressBar",
                elementLocator: { locator: "#progressBar", locatorType: LocatorType.CSS },
                backupLocators: [{ locator: "//div[contains(@class,'lightbox-cover')]/following-sibling::div[@class='progress']", locatorType: LocatorType.XPATH }]
            };
        },
    };        

    /**
     * Enters the email in the email input
     * @param email User email id as a string
     */
    async enterEmail(email: string) {
        const logger = startStep(`enterEmail: ${email}`, this.actions.logLabel);

        await this.actions.waitForElement(this.elements.emailInput());
        await this.actions.click(this.elements.emailInput());
        await this.actions.input(this.elements.emailInput(), email);

        logger.end();
    }

    /**
     * Enters the password in the password input
     * @param password password for the email id as a string
     */
    async enterPassword(password: string) {
        const logger = startStep(`enterPassword: ${password}`, this.actions.logLabel);

        await this.actions.waitForElement(this.elements.passwordInput());
        await this.actions.click(this.elements.passwordInput());
        await this.actions.inputPressSequentially(this.elements.passwordInput(), password);

        logger.end();
    }

    /**
     * Click on the submit button
     */
    async clickSubmitButton() {
        const logger = startStep('clickSubmitButton', this.actions.logLabel);
        await this.actions.waitForElement(this.elements.submit());
        await this.actions.click(this.elements.submit());
        try {
            await this.actions.waitForElement(this.elements.progressBar(), 5000);
        } catch (error) {
            // Do nothing
        }
        await this.actions.waitForElementToDisappear(this.elements.progressBar());
        logger.end();
    }

    /**
     * Choose the stay signed in option to continue
     */
    async selectstaySignedInOptions() {
        const logger = startStep('selectstaySignedInOptions', this.actions.logLabel);
        await this.actions.clickIfPresent(this.elements.submit());
        logger.end();
    }

 
    async reLoginAfterSignOut(user: IUser, isSameUser: boolean) {
        const logger = startStep('reLoginAfterSignOut', this.actions.logLabel);
        this.actions.clickIfPresent(this.elements.logBackIn());
        if (isSameUser) {
            this.tenantUserLogin(user);
        } else {
            this.actions.isElementPresent(this.elements.useAnotherAccount());
            this.actions.click(await this.elements.useAnotherAccount());
            this.tenantUserLogin(user);
        }
        logger.end();
    }
}
