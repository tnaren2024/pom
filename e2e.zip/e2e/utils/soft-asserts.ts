import { assertEquals, assertNotEquals, assertTrue } from "./assert-utils";

export class SoftAssert {
    private assertions: any[] = [];
    private description: string;

    constructor(description = "") {
        this.description = description;
    }

    /**
     * Assert that the actual value is equal to the expected value
     * @param actual Actual value
     * @param expected Expected value
     * @param failureMessage Message to display if the assertion fails
     */
    assertEquals(actual: any, expected: any, failureMessage?: string) {
        const assertion = () => assertEquals(actual, expected, failureMessage);
        this.assertions.push(assertion);
    }

    /**
     * Assert that the actual value is not equal to the expected value
     * @param actual Actual value
     * @param expected Expected value
     * @param failureMessage Message to display if the assertion fails
     */
    assertNotEquals(actual: any, expected: any, failureMessage?: string) {
        const assertion = () => assertNotEquals(actual, expected, failureMessage);
        this.assertions.push(assertion);
    }

    /**
     * Assert that the actual value is true
     * @param actual Actual value
     * @param failureMessage Message to display if the assertion fails
     */
    assertTrue(actual: any, failureMessage?: string) {
        const assertion = () => assertTrue(actual, failureMessage);
        this.assertions.push(assertion);
    }

    /**
     * Verify all the assertions. If any of the assertions fail, it will throw an error.
     * @param failureMessage Message to display if the assertion fails
     */
    assertAll(failureMessage: string) {
        const exceptions: any[] = [];
        this.assertions.forEach(assertion => {
            try {
                assertion();
            } catch (e) {
                exceptions.push(e);
            }
        });
        if (exceptions.length > 0) {
            const message = `SoftAssert failed: ${this.description} :: ${failureMessage}`;
            console.error(message);
            console.log("Failure exceptions:");
            this.printAllExceptions(exceptions);
            throw new Error(message);
        } else {
            console.log(`SoftAssert passed: ${this.description}`);
        }
    }

    private printAllExceptions(exceptions: any[]) {
        exceptions.forEach(e => {
            console.error(e);
        });
    }
}
