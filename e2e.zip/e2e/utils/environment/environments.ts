export enum TestEnvironment {
    DEV = "dev",
}

export interface ITestEnvironment {
    appUrl: string;
    secretsUrl: string;
    canSeedData?: boolean;
}

/**
 * Add any new environment data here
 */
export const environments = {
    dev: {
        appUrl: "",
        secretsUrl: "",
        canSeedData: true
    } as ITestEnvironment

};
