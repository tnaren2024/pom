import { ITestEnvironment, TestEnvironment, environments } from "./environments";

/**
 * Each test suite uses different AAD tenant.
 * This function returns the default tenant type based on the suite name.
 * @returns Tenant type (default: core_test)
 */
// export const getDefaultTenantType = (): AadTenantType => {
//     const suiteName = process.env.SUITE_NAME;

//     if (!suiteName) {
//         return AadTenantType.CORE_TEST;
//     }
//     if (suiteName.includes("authentication")) {
//         return AadTenantType.AUTHENTICATION_TEST;
//     }
//     if (suiteName.includes("msteams")) {
//         return AadTenantType.MSTEAMS_TEST;
//     }
//     if (suiteName.includes("adoextension")) {
//         return AadTenantType.ADOEXTENSION_TEST;
//     }
//     if (suiteName.includes("tenantadmin")) {
//         return AadTenantType.TENANTADMIN_TEST;
//     }
//     return AadTenantType.CORE_TEST;
// };

/**
 * This function returns the test environment based on the env variable TEST_ENVIRONMENT.
 * @returns Test environment (default: dev)
 */

export const getTestEnvironment = (): TestEnvironment => {
    const env = process.env.TEST_ENVIRONMENT;
    if (!env) {
        return TestEnvironment.DEV;
    }
    return env as TestEnvironment;
};

/**
 * Is the test running in CI?
 * @returns Test is running in CI
 */
export const isCI = (): boolean => {
    const ci = process.env.CI;
    if (ci?.toLocaleLowerCase() === "false") {
        return false;
    }
    return !!ci;
};

/**
 * App url is different for each environment.
 * @param env (optional) Test environment (default: from env variable TEST_ENVIRONMENT)
 * @returns App url
 */
export const getAppUrl = (env?: TestEnvironment): string => {
    return getEnvironemtData(env).appUrl;
};

/**
 * Secrets url is different for each environment.
 * @param env (optional) Test environment (default: from env variable TEST_ENVIRONMENT)
 * @returns Secrets url
 */
export const getSecretsUrl = (env?: TestEnvironment): string => {
    return getEnvironemtData(env).secretsUrl;
};

/**
 * Does the environment allow seeding data?
 * @param env (optional) Test environment (default: from env variable TEST_ENVIRONMENT)
 * @returns environment allows seeding data
 */
export const canSeedData = (env?: TestEnvironment): boolean => {
    return getEnvironemtData(env).canSeedData ?? false;
};

/**
 * Get environment data based on the env variable TEST_ENVIRONMENT
 * @param env (optional) Test environment (default: from env variable TEST_ENVIRONMENT)
 * @returns Environment data
 */
export const getEnvironemtData = (env?: TestEnvironment): ITestEnvironment => {
    env ??= getTestEnvironment();
    if (!environments[env]) {
        throw new Error(`Invalid environment value: ${env}`);
    }
    return environments[env];
};

/**
 * Get url which user need to open to access the org in test data
 * @param orgUuid Org uuid
 * @param env (optional) Test environment (default: from env variable TEST_ENVIRONMENT)
 * @returns Org url
 */
export const getUserOrgUrl = (orgUuid?: string, env?: TestEnvironment): string => {
    const appUrl = getAppUrl(env);
    if (!orgUuid) {
        return appUrl;
    }
    return `${appUrl}/org_uuid/${orgUuid}`;
};
