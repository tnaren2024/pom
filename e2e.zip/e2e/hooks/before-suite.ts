import { Config, chromium } from "@playwright/test";
import { startStep, consoleLog, LogMarker } from "../services/log-handler";
import { resetFallBackLocators } from "../services/playwright/page_element";
import { getAppUrl } from "../utils/environment/env-utils";
import { Actions } from "../services/playwright/actions";


export default async function globalSetup(_config: Config) {

    const logger = startStep("Before suite hook");
    resetFallBackLocators();
    consoleLog(LogMarker.NONE, "Performing setup actions before test suite execution...");
    await waitForAppLoad();
    logger.end();
    
}

const waitForAppLoad = async () => {
    const logger = startStep("Wait for app UI to be loaded");
    const browser = await chromium.launch();
    const page = await browser.newPage();
    
    const actions = new Actions(page);

    // Read user credentials from JSON file
    const userData = require('sources\GoalsV2\client\apps\viva-goals-app\e2e\resources\test-data\login-creds.json');

    // JSON file contains a structure like { "username": "your_username", "password": "your_password" }
    const { email, password } = userData;

    // Perform actions using the credentials

    await actions.goto(getAppUrl(), 60000); // 1 minute
    await actions.input({ emailId: email, passwordInput: password });
    await actions.click('Login');

    // Add more actions as needed...
    await browser.close();
    logger.end();
}
