import { test } from '@playwright/test';
import { Actions } from './services/playwright/actions';
import { getAnnotations } from './utils/tag-utils';

export type VivatTestFixture = {
    actions: Actions;
};

export const vivaTest = test.extend<VivatTestFixture>({
    actions: async ({ page }, use) => {

        const title = test.info().title;
        const annotationsResponse = getAnnotations(title);

        if (!annotationsResponse.success) {
            console.error(`Test ${title} has errors:: ${annotationsResponse.errors.join(', ')}`);
            // Instead of throwing error, continue without annotations
            test.info().annotations = []; // Reset annotations
        } else {
            // Add annotations if available
            test.info().annotations.push(...annotationsResponse.annotations);
        }

        const actions = new Actions(page);
        use(actions);
    }
});